<div class="content-wrapper">Dashboard</div>

<?php echo $this->session->flashdata('success'); ?>