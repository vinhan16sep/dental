<div class="view-search">
	<div class="container">
		<div class="overview">
			<h3>
				Tìm kiếm
			</h3>
		</div>

		<div class="list-table-responsive">
			<div class="list-items list-table list-results">
				<div class="list-items-header">
					<div class="item">
						<div class="item-row">
							<div class="item-col-12">
								<p class="p-sm">
									10 Kết quả
								</p>
							</div>
						</div>
					</div>
				</div>
				<div class="list-items-body">
					<?php for($i = 0; $i < 10; $i++): ?>
						<div class="item">
							<a href="#" class="item-row">
								<div class="item-col-4">
									<div class="img-mask">
										<img src="" alt="">
									</div>
								</div>
								<div class="item-col-8">
									<h6>
										Result search
									</h6>
								</div>
							</a>
						</div>
					<?php endfor; ?>
				</div>
			</div>
		</div>
	</div>
</div>