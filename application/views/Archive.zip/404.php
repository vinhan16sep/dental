<link rel="stylesheet" href="<?php echo site_url('assets/public/lib/') ?>bootstrap/css/bootstrap.min.css">
<div class="jumbotron">
	<div class="container">
  		<h1>ERROR 404</h1>
  	</div>
</div>