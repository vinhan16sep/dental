<!-- /.content-wrapper -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Admin Controller by <a href="javascript:void(0);" target="_blank">CNC team</a>.</strong> All rights reserved.
</footer>


</body>

<!-- fastClick -->
<script src="<?php echo site_url('assets/admin/lib/') ?>fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo site_url('assets/admin/lib/') ?>dist/js/adminlte.min.js"></script>
<script src="<?php echo site_url('assets/admin/lib/') ?>dist/js/moment.min.js"></script>
<script src="<?php echo site_url('assets/admin/lib/') ?>dist/js/daterangepicker.js"></script>
<script src="<?php echo site_url('assets/admin/') ?>js/pikaday.js"></script>
<script src="<?php echo site_url('assets/admin/') ?>js/admin/script.js"></script>

<script src="<?php echo site_url('assets/admin/') ?>js/admin/common.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/admin/js/admin/menu.js'); ?>"></script>
<script type="text/javascript">
	$(document).ready(function (){
		$("[data-toggle=tooltip]").tooltip()
	})
</script>
</html>